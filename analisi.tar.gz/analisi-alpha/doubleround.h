#ifndef DOUBLEROUND_H
#define DOUBLEROUND_H


class DoubleRound
{
private:
    DoubleRound();
public:
    static void round(double * d);
};

#endif // DOUBLEROUND_H
